export const firebaseConfig = {
    apiKey: "AIzaSyCh-jT1pzTDSeIPtHhLlZFFv8b1UyraE10",
    authDomain: "ssms-57461.firebaseapp.com",
    databaseURL: "https://ssms-57461.firebaseio.com",
    projectId: "ssms-57461",
    storageBucket: "ssms-57461.appspot.com",
    messagingSenderId: "645121434486"
  };