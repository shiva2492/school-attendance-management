import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-feedback',
  templateUrl: './live-feedback.component.html',
  styleUrls: ['./live-feedback.component.css']
})
export class LiveFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  onLiveFeedback(){
    
  }

}
