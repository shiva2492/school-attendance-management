import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-booking',
  templateUrl: './student-booking.component.html',
  styleUrls: ['./student-booking.component.css']
})
export class StudentBookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  onStudentbookin(){
    
  }

}
