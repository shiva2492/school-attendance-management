import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import * as firebase from 'firebase';


@Injectable()
export class DatabaseService {
public userList:any;
  constructor(public auth: AuthService ,public db: AngularFireDatabase) {
   
    
  }

   getUsers(){

     this.db.list('/list').subscribe(res => {
          console.log(res);
          this.userList =res;
    
       });

   }

    setUser(){
      
    } 


}
